from django.contrib import admin
from .models import Movie,Profile

admin.site.register(Movie)
admin.site.register(Profile)




