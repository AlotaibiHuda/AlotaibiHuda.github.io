from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.urls import reverse, reverse_lazy
from django.contrib import messages
from .forms import ContactForm, MovieForm, UserForm, ProfileForm, LoginForm
from .models import Movie

from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import authenticate, login, logout

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth.models import User

def is_admin_group(user):
    return user.groups.filter(name='admin').exists()

def private_view(request):
    if is_admin_group(request.user):
        return render(request, 'private.html', {})
    else:
        return HttpResponseRedirect(reverse('index'))

class MovieCreate(CreateView):
    model = Movie
    fields = '__all__'
    template_name = 'movie_form.html'

class MovieUpdate(UpdateView):
    model = Movie
    fields = '__all__'
    template_name = 'movie_form.html'

class BookDelete(DeleteView):
    model = Movie
    success_url = reverse_lazy('index')
    template_name = 'movie_confirm_delete.html'

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))

def user_login(request):
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            user = authenticate(username=username, password=password)
            if user:
                if user.is_active:
                    login(request, user)
                    return HttpResponseRedirect(reverse('index'))
                else:
                    messages.error(request, 'user is not active')
            else:
                messages.error(request, 'invalid username of password')
    
    data = {'form': form}
    return render(request, 'login.html', data)

def register(request):
    userForm = UserForm()
    profileForm = ProfileForm()

    if request.method == 'POST':
        userForm = UserForm(request.POST)
        profileForm = ProfileForm(request.POST)

        if userForm.is_valid() and profileForm.is_valid():
            user = userForm.save(commit=False)
            user.set_password(user.password)
            user.save()

            profile = profileForm.save(commit=False)
            profile.user = user
            profile.save()
            return HttpResponseRedirect(reverse('index'))

    data = { 'userForm': userForm, 'profileForm': profileForm}
    return render(request, 'register.html', data)


def index(request):
    movies = Movie.objects.all()
    data = {
        'movies': movies
     }
    return render(request, 'index.html', data)

def detail(request, pk):    
    movie = get_object_or_404(Movie, pk=pk)    
    data = {
        'movie': movie
    }
    return render(request, 'detail.html', data)

def add_movie(request):
    form = MovieForm()
    if request.method == 'POST':
        form = MovieForm(request.POST)
        if form.is_valid():
            movie = form.save(commit=False)
            if 'picture' in request.FILES:
                movie.picture = request.FILES['picture']
            movie.save()            
            messages.success(request, 'your movie have been added succesfully')
            return HttpResponseRedirect(reverse('index'))

    data = {
        'form': form
    }
    return render(request, 'add.html', data)

def contact(request):
    form = ContactForm()

    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            body = form.cleaned_data['body']
            send_email(name, email, body)
            form = ContactForm()
            messages.success(request, 'email is sent, we will contact you soon')
            return HttpResponseRedirect(reverse('contact'))
    data = { 
        'form': form
    }
    return render(request, 'contact.html', data)

def send_email(name, email, body):
    print('sending email done')