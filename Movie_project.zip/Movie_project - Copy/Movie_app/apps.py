from django.apps import AppConfig


class MovieAppConfig(AppConfig):
    name = 'Movie_app'
